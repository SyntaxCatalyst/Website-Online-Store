/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      fontFamily: {
        'sf-regular': 'SfProDisplay-Regular',
        'sf-bold': 'SfProDisplay-Bold',
        'sf-light': 'SfProDisplay-Light',
        'sf-medium': 'SfProDisplay-Medium',
        'sf-semibold': 'SfProDisplay-Semibold',
      },
      colors: {
        base: {
          black: '#101010',
          white: '#FFFFFF',
        },
        main: {
          1: '#1374e9',
          2: '#438CE4',
        },
        grey: {
          10: '#878787',
          20: '#D9D9D9',
          30: '#38383A',
          40: '#242526',
          50: '#1B1C1E',
          70: '#1B1A1A',
          90: '#101010',
        },
        red: {
          70: '#E52323',
        },
        green: {
          70: '#49E049',
        },
        warning: {
          70: '#FFC107',
        },
      },
    },
  },
  plugins: [],
};
