import {translate} from '@src/locale';
import {BASE_URL} from '@src/utils/constant';
import {showToast} from '@src/utils/toast';
import axios from 'axios';

const apiBaseConfig = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache',
  },
  timeout: 60000,
});

apiBaseConfig.interceptors.request.use(
  config => {
    return config;
  },
  error => {
    return error;
  },
);

apiBaseConfig.interceptors.response.use(
  response => {
    return response;
  },
  async error => {
    const errorMsg =
      error?.response?.data?.message ===
      'Invalid Tiktok URL. Make sure your url is correct!'
        ? translate('invalidUrl')
        : error?.response?.data?.message ?? error.response.message;
    showToast('error', errorMsg);
    return error;
  },
);

export default apiBaseConfig;
