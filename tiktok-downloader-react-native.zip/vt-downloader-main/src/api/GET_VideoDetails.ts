import {useMutation} from '@tanstack/react-query';
import api from './apiBaseConfig';
import {VideoInterface} from '@src/interfaces/VideoInterface';

export interface ResponseVideoDetails {
  success: boolean;
  data: VideoInterface;
}

export interface RequestVideoDetails {
  url: string;
}

export const getVideoDetails = async (params: RequestVideoDetails) => {
  try {
    const response = await api.get<ResponseVideoDetails>('/tiktok/download', {
      params,
    });
    return response.data;
  } catch (error: any) {
    throw error.response.data;
  }
};

export const useGetVideoDetails = () => {
  return useMutation<ResponseVideoDetails, unknown, RequestVideoDetails>({
    mutationFn: getVideoDetails,
  });
};
