import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {NavigationContainer} from '@react-navigation/native';
import useKeyboard from '@src/hooks/useKeyboard';
import {RootStackParamList} from '@src/interfaces/NavigationInterface';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import Home from '@src/screens/Home';
import History from '@src/screens/History';
import {navigationRef} from '@src/utils/navigation';
import Splash from '@src/screens/Splash';
import BottomNavigator from '@src/components/BottomNavigation';
import VideoDetails from '@src/screens/VideoDetails';
import Settings from '@src/screens/Settings';
import ChangeBackground from '@src/screens/ChangeBackground';
import ChangeLanguage from '@src/screens/ChangeLanguage';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator();

const Main = () => {
  const isKeyboardShow = useKeyboard();

  return (
    <Tab.Navigator
      tabBar={props => {
        return isKeyboardShow ? null : <BottomNavigator {...props} />;
      }}
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
      }}
      backBehavior="history">
      <Tab.Screen name="Home" component={Home} />
      <Tab.Screen name="History" component={History} />
      <Tab.Screen name="Settings" component={Settings} />
    </Tab.Navigator>
  );
};

export default function Navigation() {
  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator
        initialRouteName="Splash"
        screenOptions={{
          headerShown: false,
          animation: 'slide_from_right',
          contentStyle: {
            backgroundColor: '#fff',
          },
        }}>
        <Stack.Screen name="Main" component={Main} />
        <Stack.Screen name="Splash" component={Splash} />
        <Stack.Screen name="VideoDetails" component={VideoDetails} />
        <Stack.Screen name="ChangeBackground" component={ChangeBackground} />
        <Stack.Screen name="ChangeLanguage" component={ChangeLanguage} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
