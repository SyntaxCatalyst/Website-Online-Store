import Clipboard from '@react-native-clipboard/clipboard';

export const onCopy = (text: string) => {
  Clipboard.setString(text);
};
