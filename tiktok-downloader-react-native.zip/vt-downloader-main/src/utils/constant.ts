export const BASE_URL = 'https://api.mempawahdeveloper.my.id'; // Ubah menggunakan api kamu

export const DATA_BACKGROUND = [
  {id: 1, image: require('@src/assets/images/background2.jpg')},
  {id: 2, image: require('@src/assets/images/background.jpg')},
  {id: 3, image: require('@src/assets/images/background3.jpg')},
];
