import {atom} from 'jotai';
import {storage} from '../utils/storage';
import {VideoInterface} from '../interfaces/VideoInterface';
import {translation} from '@src/locale';

export const dataListAtom = atom<VideoInterface[]>(
  storage.getString('data_list')
    ? (JSON.parse(storage.getString('data_list')!) as VideoInterface[])
    : [],
);

export const addDataListAtom = atom(null, (get, set, value: VideoInterface) => {
  if (!get(dataListAtom).find(item => item.id === value.id)) {
    const updatedValues = [value, ...get(dataListAtom)];
    storage.set('data_list', JSON.stringify(updatedValues));
    set(dataListAtom, updatedValues);
  }
});

export const removeDataListAtom = atom(
  null,
  (get, set, value: VideoInterface) => {
    const updatedValues = get(dataListAtom).filter(
      item => item.id !== value.id,
    );
    storage.set('data_list', JSON.stringify(updatedValues));
    set(dataListAtom, updatedValues);
  },
);

export const isSaveSearchAtom = atom<boolean>(
  storage.getBoolean('is_save') ?? true,
);

export const toggleIsSaveSearchAtom = atom(null, (get, set) => {
  const isSave = get(isSaveSearchAtom);
  storage.set('is_save', !isSave);
  set(isSaveSearchAtom, !isSave);
});

export const backgroundAtom = atom<number>(
  storage.getNumber('background_number') ?? 1,
);

export const setBackgroundAtom = atom(null, (get, set, value: number) => {
  storage.set('background_number', value);
  set(backgroundAtom, value);
});

export const langAtom = atom<string>(storage.getString('lang_id') ?? 'en');

export const setLangAtom = atom(null, (get, set, value: string) => {
  storage.set('lang_id', value);
  set(langAtom, value);
  translation.changeLanguage(value);
});
