import {translate} from '@src/locale';
import {showToast} from '@src/utils/toast';
import React from 'react';
import {PermissionsAndroid, Platform} from 'react-native';
import ReactNativeBlobUtil from 'react-native-blob-util';

export default function useDownloadFile() {
  const [downloadProgress, setDownloadProgress] = React.useState<
    string | number | undefined
  >();
  const [downloadLoading, setDownloadLoading] = React.useState(false);
  const [downloadIsDone, setDownloadIsDone] = React.useState(false);

  const getFileExtention = (fileUrl: string) => {
    return /[.]/.exec(fileUrl) ? /[^.]+$/.exec(fileUrl) : undefined;
  };

  const downloadFile = async (
    fileUrl: string,
    type: 'video' | 'audio' | 'image' | 'file',
    onProgress: (received: number, total: number) => void,
  ) => {
    const date = new Date();
    let file_ext: any = getFileExtention(fileUrl);
    file_ext = '.' + file_ext[0];

    const {config, fs} = ReactNativeBlobUtil;
    const RootDir =
      Platform.OS === 'ios' ? fs.dirs.DocumentDir : fs.dirs.LegacyDownloadDir;

    const name =
      type === 'video'
        ? '/vt-video_'
        : type === 'audio'
        ? '/vt-audio_'
        : type === 'image'
        ? '/vt-image_'
        : '/vt-file_';

    file_ext =
      type === 'video'
        ? '.mp4'
        : type === 'audio'
        ? '.mp3'
        : type === 'image'
        ? '.png'
        : file_ext;

    const path =
      RootDir +
      name +
      Math.floor(date.getTime() + date.getSeconds() / 2) +
      file_ext;

    return config({path})
      .fetch('GET', fileUrl)
      .progress((received, total) => {
        onProgress(Number(received), Number(total));
        // setDownloadProgress(
        //   (Number((+received / +total).toFixed(2)) * 100).toFixed(0),
        // );
      })
      .then(() => {
        console.log(`File downloaded successfully: ${fileUrl}`);
      })
      .catch(() => {
        console.log(`Failed to download file: ${fileUrl}`);
      });
  };

  const handleDownloadFiles = async (
    fileUrls: string[],
    type: 'video' | 'audio' | 'image' | 'file',
  ) => {
    setDownloadLoading(true);
    setDownloadProgress(0);
    setDownloadIsDone(false);

    try {
      const permissionGranted =
        Platform.OS === 'ios' || Number(Platform.Version) >= 33
          ? true
          : (await PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
              {
                title: 'Storage Permission Required',
                message:
                  'Application needs access to your storage to download files.',
                buttonPositive: 'OK',
              },
            )) === PermissionsAndroid.RESULTS.GRANTED;

      if (!permissionGranted) {
        showToast('error', 'Storage permission not granted');
        return;
      }

      for (let i = 0; i < fileUrls.length; i++) {
        const isLastFile = i === fileUrls.length - 1;
        let totalReceived = 0;
        let totalSize = 0;

        await downloadFile(fileUrls[i], type, (received, total) => {
          totalReceived = received;
          totalSize = total;

          if (isLastFile) {
            const percentage = ((totalReceived / totalSize) * 100).toFixed(0);
            setDownloadProgress(percentage);
          } else {
            setDownloadProgress(0);
          }
        });
      }

      setDownloadIsDone(true);
      showToast('success', translate('downloadSuccess'));
    } catch (error) {
      showToast('error', translate('downloadError'));
    } finally {
      setTimeout(() => {
        setDownloadLoading(false);
        setDownloadProgress(undefined);
      }, 500);
    }
  };

  return {
    downloadProgress,
    downloadLoading,
    downloadIsDone,
    handleDownloadFiles,
  };
}
