export interface VideoInterface {
  author: {
    avatarMedium: string;
    nickname: string;
    region: string;
    url: string;
    username: string;
  };
  createTime: number;
  description: string;
  id: string;
  music: {
    album: string;
    author: string;
    coverLarge: string[];
    duration: number;
    id: number;
    playUrl: string[];
    title: string;
  };
  statistics: {
    collectCount: number;
    commentCount: number;
    diggCount: number;
    downloadCount: number;
    forwardCount: number;
    loseCommentCount: number;
    loseCount: number;
    playCount: number;
    repostCount: number;
    shareCount: number;
    whatsappShareCount: number;
  };
  type: 'video' | 'image';
  video: {
    cover: string[];
    downloadAddr: string[];
    duration: 77611;
    playAddr: string[];
  };
  images: string[];
  date: Date;
  url: string;
}
