import {NativeStackScreenProps} from '@react-navigation/native-stack';
import {VideoInterface} from './VideoInterface';

export type RootStackParamList = {
  Main: undefined;
  Splash: undefined;
  VideoDetails: {
    item: VideoInterface;
  };
  Settings: undefined;
  ChangeBackground: undefined;
  ChangeLanguage: undefined;
};

export type RootStackScreenProps<T extends keyof RootStackParamList> =
  NativeStackScreenProps<RootStackParamList, T>;

declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
    interface AccountParamList extends RootParamList {}
  }
}
