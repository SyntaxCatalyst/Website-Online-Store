import {ImageBackground, Image} from 'react-native';
import React, {useEffect} from 'react';
import {RootStackScreenProps} from '@src/interfaces/NavigationInterface';
import DefaultView from '@src/components/DefaultView';
import {useAtomValue} from 'jotai';
import {backgroundAtom, langAtom} from '@src/store/UserStore';
import {DATA_BACKGROUND} from '@src/utils/constant';
import {translation} from '@src/locale';

export default function Splash({navigation}: RootStackScreenProps<'Splash'>) {
  const background = useAtomValue(backgroundAtom);
  const lang = useAtomValue(langAtom);

  useEffect(() => {
    translation.changeLanguage(lang);
    setTimeout(() => navigation.replace('Main'), 2000);
  }, [navigation, lang]);

  return (
    <DefaultView
      translucent={true}
      backgroundColor="transparent"
      statusbarColor="transparent"
      barStyle="light-content">
      <ImageBackground
        source={DATA_BACKGROUND[background - 1].image}
        className="flex-1 justify-center items-center">
        <Image
          source={require('../../assets/splash/logo.png')}
          resizeMode="contain"
          className="w-[150px] h-[150px]"
        />
      </ImageBackground>
    </DefaultView>
  );
}
