import {ImageBackground, FlatList} from 'react-native';
import React from 'react';
import DefaultView from '../../components/DefaultView';
import Header from '@src/components/Header';
import CardBackground from '@src/components/CardBackground';
import {DATA_BACKGROUND} from '@src/utils/constant';
import {useAtomValue} from 'jotai';
import {backgroundAtom} from '@src/store/UserStore';
import {translate} from '@src/locale';

export default function ChangeBackground() {
  const background = useAtomValue(backgroundAtom);

  return (
    <DefaultView
      translucent={true}
      backgroundColor="transparent"
      statusbarColor="transparent"
      barStyle="light-content">
      <ImageBackground
        source={DATA_BACKGROUND[background - 1].image}
        className="flex-1">
        <Header title={translate('changeBackground')} />
        <FlatList
          data={DATA_BACKGROUND}
          keyExtractor={(_, key) => key.toString()}
          renderItem={({item}) => {
            return <CardBackground image={item.image} id={item.id} />;
          }}
          showsVerticalScrollIndicator={false}
          contentContainerClassName="py-3"
        />
      </ImageBackground>
    </DefaultView>
  );
}
