import {
  Image,
  ScrollView,
  View,
  TextInput,
  TouchableOpacity,
  ImageBackground,
} from 'react-native';
import React, {useState} from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAtomValue, useSetAtom} from 'jotai';
import DefaultText from '@src/components/DefaultText';
import {
  addDataListAtom,
  backgroundAtom,
  isSaveSearchAtom,
} from '@src/store/UserStore';
import DefaultView from '@src/components/DefaultView';
import LoaderFullScreen from '@src/components/LoaderFullScreen';
import {useGetVideoDetails} from '@src/api/GET_VideoDetails';
import {showToast} from '@src/utils/toast';
import Gap from '@src/components/Gap';
import Clipboard from '@react-native-clipboard/clipboard';
import {DATA_BACKGROUND} from '@src/utils/constant';
import {VideoInterface} from '@src/interfaces/VideoInterface';
import CardVideo from '@src/components/CardVideo';
import {translate} from '@src/locale';
import {useTranslation} from 'react-i18next';

export default function Home() {
  const [search, setSearch] = useState('');
  const [data, setData] = useState<VideoInterface>();
  const addDataList = useSetAtom(addDataListAtom);
  const mutationVideoDetails = useGetVideoDetails();
  const background = useAtomValue(backgroundAtom);
  const isSaveSearch = useAtomValue(isSaveSearchAtom);
  useTranslation();

  const getData = async (text: string) => {
    setData(undefined);
    const response = await mutationVideoDetails.mutateAsync({url: text});
    if (response?.success) {
      setData(response.data);
      if (isSaveSearch) {
        addDataList({...response.data, url: text, date: new Date()});
      }
    }
  };

  const onSearch = async () => {
    if (search.trim().length === 0) {
      return showToast('info', translate('inputWarning'));
    }
    getData(search);
  };

  const onPaste = async () => {
    const text = await Clipboard.getString();
    if (text?.trim()?.length === 0) {
      return showToast('info', translate('textIsEmpty'));
    }
    getData(text);
    setSearch(text);
  };

  return (
    <DefaultView
      translucent={true}
      backgroundColor="transparent"
      statusbarColor="transparent"
      barStyle="light-content">
      <LoaderFullScreen show={mutationVideoDetails.isPending} />
      <ImageBackground
        source={DATA_BACKGROUND[background - 1].image}
        className="flex-1"
        imageClassName="transform rotate-180">
        <View className="flex-row items-center px-4 py-2 mt-12">
          <Image
            source={require('../../assets/splash/logo.png')}
            className="w-12 h-12"
            resizeMode="contain"
          />
          <View className="flex-1 mx-2">
            <DefaultText
              title={translate('welcome')}
              titleClassName="font-sf-semibold text-white text-lg"
            />
            <DefaultText
              title={translate('enterTiktok')}
              titleClassName="text-sm text-white"
            />
          </View>
        </View>
        <ScrollView showsVerticalScrollIndicator={false} className="px-4 py-4">
          <View className="flex-row items-center gap-3">
            <TextInput
              placeholder={translate('tiktokUrl')}
              placeholderTextColor="#ccc"
              className="bg-white/10 rounded-lg px-4 text-white flex-1 h-14 font-sf-regular"
              returnKeyType="search"
              value={search}
              onChangeText={setSearch}
              onSubmitEditing={onSearch}
            />
            <TouchableOpacity
              activeOpacity={0.7}
              className="bg-white/30 rounded-xl h-14 w-14 justify-center items-center"
              onPress={onSearch}>
              <Icon name="magnify" color="#fff" size={30} />
            </TouchableOpacity>
          </View>
          <Gap height={25} />
          <TouchableOpacity
            activeOpacity={0.7}
            className="bg-white/30 rounded-xl h-14 justify-center items-center flex-row gap-2"
            onPress={onPaste}>
            <Icon name="content-paste" color="#fff" size={20} />
            <DefaultText
              title={translate('pasteSearch')}
              titleClassName="font-sf-semibold text-lg"
            />
          </TouchableOpacity>
          {data ? (
            <>
              <Gap height={20} />
              <CardVideo item={data} isHistory={false} />
            </>
          ) : null}
        </ScrollView>
      </ImageBackground>
    </DefaultView>
  );
}
