import React from 'react';
import DefaultView from '@src/components/DefaultView';
import VideoDetailsButtons from './VideoDetailsButtons';
import {RootStackScreenProps} from '@src/interfaces/NavigationInterface';
import VideoDetailsContent from './VideoDetailsContent';
import VideoDetailsPlayer from './VideoDetailsPlayer';
import VideoDetailsImages from './VideoDetailsImages';

export default function VideoDetails({
  route,
}: RootStackScreenProps<'VideoDetails'>) {
  const item = route.params.item;

  return (
    <DefaultView
      translucent={true}
      backgroundColor="#000"
      statusbarColor="transparent"
      barStyle="light-content">
      <VideoDetailsButtons item={item} />
      <VideoDetailsContent item={item} />
      {item.type === 'video' && (
        <VideoDetailsPlayer uri={item.video.playAddr[0]} />
      )}
      {item.type === 'image' && (
        <VideoDetailsImages
          images={item.images}
          musicUri={item.music.playUrl?.[0] ?? ''}
        />
      )}
    </DefaultView>
  );
}
