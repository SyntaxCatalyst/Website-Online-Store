import {ScrollView, View} from 'react-native';
import React, {useState} from 'react';
import {VideoInterface} from '@src/interfaces/VideoInterface';
import DefaultText from '@src/components/DefaultText';
import Gap from '@src/components/Gap';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Marquee from '@src/components/Marquee';
import {onCopy} from '@src/utils/copy';

export default function VideoDetailsContent({item}: {item: VideoInterface}) {
  const MAX_LENGTH = 50;
  const [isExpanded, setIsExpanded] = useState(
    item.description.trim().length <= 100 ? true : false,
  );

  const toggleText = () => setIsExpanded(!isExpanded);

  return (
    <View className="absolute bottom-0 left-0 w-[65%] max-h-[65%] z-10">
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerClassName="pl-5 pb-5">
        <DefaultText
          title={item.author.nickname}
          titleClassName="text-white font-sf-semibold"
        />
        <Gap height={10} />
        <DefaultText
          title={
            isExpanded
              ? item.description
              : `${item.description.slice(0, MAX_LENGTH)}...`
          }
          titleClassName="text-white"
          titlePress={() => onCopy(item.description)}
        />
        <DefaultText
          title={isExpanded ? 'Less' : 'More'}
          titleClassName="text-white mt-2 font-sf-medium"
          titlePress={toggleText}
        />
        <Gap height={10} />
        <View className="flex-row items-center gap-2">
          <Icon name="music" color="#fff" size={16} />
          <Marquee text={item.music?.title ?? 'No music'} />
        </View>
      </ScrollView>
    </View>
  );
}
