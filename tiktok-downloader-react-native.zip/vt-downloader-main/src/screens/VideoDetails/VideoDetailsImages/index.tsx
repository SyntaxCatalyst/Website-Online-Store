import React, {useEffect} from 'react';
import {View, Image, Dimensions} from 'react-native';
import Sound from 'react-native-sound';
import Animated, {
  useSharedValue,
  useAnimatedScrollHandler,
  interpolateColor,
  useAnimatedStyle,
} from 'react-native-reanimated';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const VideoDetailsImages = ({
  images,
  musicUri,
}: {
  images: string[];
  musicUri: string;
}) => {
  const scrollX = useSharedValue(0);

  useEffect(() => {
    const sound = new Sound(musicUri, Sound.MAIN_BUNDLE, (error: any) => {
      if (error) {
        console.error('Failed to load the sound', error);
        return;
      }
      sound.setNumberOfLoops(-1);
      sound.play();
    });

    return () => {
      sound.stop();
      sound.release();
    };
  }, [musicUri]);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: event => {
      scrollX.value = event.contentOffset.x;
    },
  });

  const PaginationDot = ({index}: {index: number}) => {
    const animatedDotStyle = useAnimatedStyle(() => {
      const backgroundColor = interpolateColor(
        scrollX.value,
        [
          (index - 1) * SCREEN_WIDTH,
          index * SCREEN_WIDTH,
          (index + 1) * SCREEN_WIDTH,
        ],
        ['#999999', '#ffffff', '#999999'],
      );

      return {
        backgroundColor,
      };
    });

    return (
      <Animated.View
        className="w-2 h-2 rounded-full mx-1"
        style={animatedDotStyle}
      />
    );
  };

  return (
    <View className="flex-1">
      <Animated.FlatList
        data={images}
        keyExtractor={(item, index) => `image-${index}`}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
        renderItem={({item}) => (
          <View
            className="overflow-hidden"
            style={{width: SCREEN_WIDTH, height: SCREEN_HEIGHT}}>
            <Image
              source={{uri: item}}
              className="w-full h-full"
              resizeMode="contain"
            />
          </View>
        )}
      />
      {images.length > 1 && (
        <View className="absolute bottom-10 self-center flex-row">
          {images.map((_, index) => (
            <PaginationDot key={index} index={index} />
          ))}
        </View>
      )}
    </View>
  );
};

export default VideoDetailsImages;
