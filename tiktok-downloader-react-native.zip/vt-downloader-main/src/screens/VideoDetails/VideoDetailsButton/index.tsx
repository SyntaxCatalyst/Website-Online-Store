import {TouchableOpacity, View} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Gap from '@src/components/Gap';
import DefaultText from '@src/components/DefaultText';
import {formatNumberToK} from '@src/utils/formatNumber';

export default function VideoDetailsButton({
  iconName,
  value,
}: {
  iconName: string;
  value: number;
}) {
  return (
    <View>
      <TouchableOpacity
        activeOpacity={0.7}
        className="bg-grey-50/50 w-14 h-14 rounded-full justify-center items-center">
        <Icon name={iconName} color="#fff" size={20} />
      </TouchableOpacity>
      <Gap height={5} />
      <DefaultText
        title={formatNumberToK(value)}
        titleClassName="text-center"
      />
    </View>
  );
}
