import {Image, View} from 'react-native';
import React from 'react';
import {VideoInterface} from '@src/interfaces/VideoInterface';

export default function VideoDetailsProfile({item}: {item: VideoInterface}) {
  return (
    <View className="w-14 h-14 rounded-full bg-grey-40 overflow-hidden border border-white">
      <Image
        source={{uri: item.author.avatarMedium[0]}}
        resizeMode="cover"
        className="w-full h-full"
      />
    </View>
  );
}
