import {View} from 'react-native';
import React from 'react';
import {VideoInterface} from '@src/interfaces/VideoInterface';
import VideoDetailsButton from '../VideoDetailsButton';
import Gap from '@src/components/Gap';
import VideoDetailsProfile from '../VideoDetailsProfile';

export default function VideoDetailsButtons({item}: {item: VideoInterface}) {
  return (
    <View className="absolute bottom-5 right-5 z-10">
      <VideoDetailsProfile item={item} />
      <Gap height={20} />
      <VideoDetailsButton
        iconName="cards-heart"
        value={item.statistics.diggCount}
      />
      <Gap height={10} />
      <VideoDetailsButton
        iconName="comment-processing"
        value={item.statistics.commentCount}
      />
      <Gap height={10} />
      <VideoDetailsButton
        iconName="bookmark"
        value={item.statistics.collectCount}
      />
      <Gap height={10} />
      <VideoDetailsButton iconName="share" value={item.statistics.shareCount} />
    </View>
  );
}
