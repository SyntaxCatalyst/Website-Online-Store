import React, {useState, useRef} from 'react';
import {View, TouchableWithoutFeedback, Dimensions} from 'react-native';
import Video, {VideoRef} from 'react-native-video';
import {Slider} from '@miblanchard/react-native-slider';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const {width: SCREEN_WIDTH} = Dimensions.get('window');

const VideoDetailsPlayer = ({uri}: {uri: string}) => {
  const videoRef = useRef<VideoRef>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const togglePlayPause = () => setIsPaused(!isPaused);

  const handleProgress = (data: {currentTime: number}) => {
    setCurrentTime(data.currentTime);
  };

  const handleLoad = (data: {duration: number}) => {
    setDuration(data.duration);
  };

  const handleSeek = (time: number[]) => {
    videoRef.current?.seek(time[0]);
    setCurrentTime(time[0]);
  };

  return (
    <View className="flex-1 bg-black">
      <TouchableWithoutFeedback onPress={togglePlayPause}>
        <Video
          ref={videoRef}
          source={{uri}}
          resizeMode="cover"
          paused={isPaused}
          onProgress={handleProgress}
          onLoad={handleLoad}
          style={{flex: 1}}
          controls={false}
          repeat={true}
        />
      </TouchableWithoutFeedback>
      <View className="absolute w-full -bottom-[15px]">
        <Slider
          containerStyle={{width: SCREEN_WIDTH, zIndex: 999}}
          minimumValue={0}
          maximumValue={duration}
          value={currentTime}
          onValueChange={handleSeek}
          minimumTrackTintColor="#FFFFFF"
          maximumTrackTintColor="#777777"
          thumbTintColor="#FFFFFF"
          thumbStyle={{width: 10, height: 10}}
        />
      </View>
      {isPaused && (
        <View className="absolute self-center justify-center items-center h-full">
          <Icon name="play" size={100} color="#fff" onPress={togglePlayPause} />
        </View>
      )}
    </View>
  );
};

export default VideoDetailsPlayer;
