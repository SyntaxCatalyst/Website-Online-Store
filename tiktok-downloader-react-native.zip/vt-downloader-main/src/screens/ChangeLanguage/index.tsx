import {ImageBackground, TouchableOpacity, View} from 'react-native';
import React from 'react';
import DefaultView from '../../components/DefaultView';
import Header from '@src/components/Header';
import {DATA_BACKGROUND} from '@src/utils/constant';
import {useAtomValue, useSetAtom} from 'jotai';
import {backgroundAtom, langAtom, setLangAtom} from '@src/store/UserStore';
import {translate} from '@src/locale';
import Gap from '@src/components/Gap';
import DefaultText from '@src/components/DefaultText';
import Choose from '@src/components/Choose';
import {RootStackScreenProps} from '@src/interfaces/NavigationInterface';

export default function ChangeLanguage({}: RootStackScreenProps<'ChangeLanguage'>) {
  const background = useAtomValue(backgroundAtom);
  const lang = useAtomValue(langAtom);
  const setLang = useSetAtom(setLangAtom);

  const onChangeLang = (id: string) => {
    setLang(id);
  };

  return (
    <DefaultView
      translucent={true}
      backgroundColor="transparent"
      statusbarColor="transparent"
      barStyle="light-content">
      <ImageBackground
        source={DATA_BACKGROUND[background - 1].image}
        className="flex-1">
        <Header title={translate('changeLanguage')} />
        <Gap height={20} />
        <View className="bg-black/40 p-4 m-3 rounded-xl">
          <TouchableOpacity
            activeOpacity={0.7}
            className="flex-row items-center gap-2 self-start"
            onPress={() => onChangeLang('en')}>
            <Choose active={lang === 'en'} />
            <DefaultText
              title="English"
              titleClassName="text-lg font-sf-medium flex-1"
            />
          </TouchableOpacity>
          <Gap height={15} />
          <TouchableOpacity
            activeOpacity={0.7}
            className="flex-row items-center gap-2 self-start"
            onPress={() => onChangeLang('id')}>
            <Choose active={lang === 'id'} />
            <DefaultText
              title="Indonesia"
              titleClassName="text-lg font-sf-medium flex-1"
            />
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </DefaultView>
  );
}
