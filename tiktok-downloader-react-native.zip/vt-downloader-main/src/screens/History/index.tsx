import {Image, Text, View, ImageBackground, FlatList} from 'react-native';
import React from 'react';
import DefaultView from '../../components/DefaultView';
import {useAtomValue} from 'jotai';
import {backgroundAtom, dataListAtom} from '../../store/UserStore';
import CardVideo from '@src/components/CardVideo';
import {DATA_BACKGROUND} from '@src/utils/constant';
import {translate} from '@src/locale';
import {useTranslation} from 'react-i18next';
import Empty from '@src/components/Empty';

export default function History() {
  const dataList = useAtomValue(dataListAtom);
  const background = useAtomValue(backgroundAtom);
  useTranslation();

  return (
    <DefaultView
      translucent={true}
      backgroundColor="transparent"
      statusbarColor="transparent"
      barStyle="light-content">
      <ImageBackground
        source={DATA_BACKGROUND[background - 1].image}
        className="flex-1"
        imageClassName="transform rotate-180">
        <View className="flex-row items-center px-4 py-2 mt-12">
          <Image
            source={require('../../assets/splash/logo.png')}
            className="w-12 h-12"
            resizeMode="contain"
          />
          <View className="flex-1 mx-3">
            <Text className="text-white font-bold text-lg">
              {translate('tiktokHistoryTitle')}
            </Text>
            <Text className="text-white text-sm">
              {translate('tiktokHistorySub')}
            </Text>
          </View>
        </View>
        <FlatList
          data={dataList}
          renderItem={({item}) => {
            return <CardVideo item={item} />;
          }}
          showsVerticalScrollIndicator={false}
          contentContainerClassName="p-4 pb-[100px]"
          ListEmptyComponent={<Empty />}
        />
      </ImageBackground>
    </DefaultView>
  );
}
