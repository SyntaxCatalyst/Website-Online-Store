import {
  Image,
  Text,
  View,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import DefaultView from '../../components/DefaultView';
import DefaultText from '@src/components/DefaultText';
import Gap from '@src/components/Gap';
import Switch from '@src/components/Switch';
import {useAtomValue, useSetAtom} from 'jotai';
import {
  backgroundAtom,
  isSaveSearchAtom,
  toggleIsSaveSearchAtom,
} from '@src/store/UserStore';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {navigationRef} from '@src/utils/navigation';
import {DATA_BACKGROUND} from '@src/utils/constant';
import {translate} from '@src/locale';
import {useTranslation} from 'react-i18next';

export default function Settings() {
  const isSaveSearch = useAtomValue(isSaveSearchAtom);
  const toggleSaveSearch = useSetAtom(toggleIsSaveSearchAtom);
  const background = useAtomValue(backgroundAtom);
  useTranslation();

  return (
    <DefaultView
      translucent={true}
      backgroundColor="transparent"
      statusbarColor="transparent"
      barStyle="light-content">
      <ImageBackground
        source={DATA_BACKGROUND[background - 1].image}
        className="flex-1"
        imageClassName="transform rotate-180">
        <View className="flex-row items-center px-4 py-2 mt-12">
          <Image
            source={require('../../assets/splash/logo.png')}
            className="w-12 h-12"
            resizeMode="contain"
          />
          <View className="flex-1 mx-3">
            <Text className="text-white font-bold text-lg">
              {translate('tiktokSettings')}
            </Text>
            <Text className="text-white text-sm">
              {translate('tiktokSettingsSub')}
            </Text>
          </View>
        </View>
        <Gap height={30} />
        <View className="px-3 py-2 flex-row items-center">
          <DefaultText
            title={translate('saveMyHistory')}
            titleClassName="font-sf-semibold text-lg flex-1"
          />
          <Switch value={isSaveSearch} onValueChange={toggleSaveSearch} />
        </View>
        <Gap height={10} />
        <TouchableOpacity
          className="px-3 py-2 flex-row items-center"
          activeOpacity={0.7}
          onPress={() => navigationRef.navigate('ChangeBackground')}>
          <DefaultText
            title={translate('changeBackground')}
            titleClassName="font-sf-semibold text-lg flex-1"
          />
          <Icon name="chevron-right" size={26} color="#fff" />
        </TouchableOpacity>
        <Gap height={10} />
        <TouchableOpacity
          className="px-3 py-2 flex-row items-center"
          activeOpacity={0.7}
          onPress={() => navigationRef.navigate('ChangeLanguage')}>
          <DefaultText
            title={translate('changeLanguage')}
            titleClassName="font-sf-semibold text-lg flex-1"
          />
          <Icon name="chevron-right" size={26} color="#fff" />
        </TouchableOpacity>
      </ImageBackground>
    </DefaultView>
  );
}
