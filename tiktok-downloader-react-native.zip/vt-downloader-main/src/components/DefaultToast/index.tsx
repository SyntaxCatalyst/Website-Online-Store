import React from 'react';
import {View, useWindowDimensions} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import DefaultText from '../DefaultText';

interface DefaultToastProps {
  title: string;
  type: 'success' | 'error' | 'info';
}
export default function DefaultToast({type, title}: DefaultToastProps) {
  const {width} = useWindowDimensions();

  const backgroundColor =
    type === 'success'
      ? 'bg-green-70'
      : type === 'error'
      ? 'bg-red-70'
      : 'bg-warning-70';

  return (
    <View
      className={`p-3 flex-row items-center rounded-lg ${backgroundColor}`}
      style={{width: width * 0.95}}>
      <Icon
        name={
          type === 'success'
            ? 'check-circle'
            : type === 'info'
            ? 'information'
            : 'close-circle'
        }
        size={20}
        color="#fff"
      />
      <DefaultText title={title} titleClassName="flex-1 ml-2 text-white" />
    </View>
  );
}
