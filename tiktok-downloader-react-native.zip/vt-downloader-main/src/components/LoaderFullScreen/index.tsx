import React from 'react';
import {ActivityIndicator, View} from 'react-native';
import Modal from 'react-native-modal';

export default function LoaderFullScreen({show}: {show: boolean}) {
  return (
    <Modal isVisible={show} backdropOpacity={0.5}>
      <View className="bg-black/50 self-center p-5 rounded-lg">
        <ActivityIndicator color="#fff" size="large" />
      </View>
    </Modal>
  );
}
