import {StatusBar, StatusBarStyle, View} from 'react-native';
import React, {ReactNode} from 'react';
import {useIsFocused} from '@react-navigation/native';
import {
  SafeAreaProvider,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';

const DefaultView = ({
  barStyle,
  children,
  translucent,
  statusbarColor,
  backgroundColor,
}: {
  barStyle?: StatusBarStyle;
  children?: ReactNode;
  translucent?: boolean;
  statusbarColor?: string;
  backgroundColor?: string;
}) => {
  const isFocused = useIsFocused();

  const insets = useSafeAreaInsets();

  return (
    <SafeAreaProvider>
      <View
        className={`h-${translucent ? 0 : insets.top} ${
          statusbarColor ? '' : 'bg-white'
        }`}
        style={{backgroundColor: statusbarColor ?? '#fff'}}>
        {isFocused && (
          <StatusBar
            animated={true}
            barStyle={barStyle ?? 'dark-content'}
            backgroundColor={statusbarColor ?? '#fff'}
            translucent={translucent ?? false}
          />
        )}
      </View>
      <View
        className="flex-1"
        style={{backgroundColor: backgroundColor || 'transparent'}}>
        {children}
      </View>
    </SafeAreaProvider>
  );
};

export default DefaultView;
