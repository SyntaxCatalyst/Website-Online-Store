import {TouchableOpacity, View} from 'react-native';
import React from 'react';
import Modal from 'react-native-modal';
import DefaultText from '../DefaultText';
import Gap from '../Gap';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {VideoInterface} from '@src/interfaces/VideoInterface';
import {translate} from '@src/locale';

interface ModalDownloadInterface {
  show: boolean;
  hide: () => void;
  item: VideoInterface;
  onDownloadVideo: () => void;
  onDownloadAudio: () => void;
}

export default function ModalDownload({
  show,
  hide,
  item,
  onDownloadVideo,
  onDownloadAudio,
}: ModalDownloadInterface) {
  return (
    <Modal
      isVisible={show}
      onBackButtonPress={hide}
      onBackdropPress={hide}
      className="m-0"
      statusBarTranslucent={false}>
      <View className="bg-black rounded-lg p-4">
        <Icon
          name="close"
          color="#fff"
          size={20}
          className="absolute right-2 top-2 z-10"
          onPress={hide}
        />
        <DefaultText
          title={translate('download')}
          titleClassName="font-sf-semibold text-lg text-center"
        />
        <Gap height={15} />
        <TouchableOpacity
          activeOpacity={0.7}
          className="flex-row items-center gap-2 bg-black/20 p-3 rounded-lg"
          onPress={onDownloadVideo}>
          <Icon name="download" size={18} color="#fff" />
          <DefaultText
            title={
              item.type === 'video'
                ? translate('downloadVideo')
                : translate('downloadImage')
            }
            titleClassName="font-sf-medium"
          />
        </TouchableOpacity>
        {item.music ? (
          <>
            <Gap height={15} />
            <TouchableOpacity
              activeOpacity={0.7}
              className="flex-row items-center gap-2 bg-black/20 p-3 rounded-lg"
              onPress={onDownloadAudio}>
              <Icon name="download" size={18} color="#fff" />
              <DefaultText
                title={translate('downloadAudio')}
                titleClassName="font-sf-medium"
              />
            </TouchableOpacity>
          </>
        ) : null}
      </View>
    </Modal>
  );
}
