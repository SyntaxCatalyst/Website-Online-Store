import {ActivityIndicator, View} from 'react-native';
import React from 'react';
import Modal from 'react-native-modal';
import DefaultText from '../DefaultText';
import Gap from '../Gap';

interface ModalPercentageInterface {
  show: boolean;
  percentage: number;
}

export default function ModalPercentage({
  show,
  percentage,
}: ModalPercentageInterface) {
  return (
    <Modal isVisible={show} className="m-0">
      <View className="bg-black/50 self-center px-10 py-5 rounded-2xl">
        <ActivityIndicator color="#fff" size="large" />
        <Gap height={10} />
        <DefaultText title={`${percentage}%`} titleClassName="text-center" />
      </View>
    </Modal>
  );
}
