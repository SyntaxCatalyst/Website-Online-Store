import {View} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import DefaultText from '../DefaultText';
import {navigationRef} from '@src/utils/navigation';

interface HeaderInterface {
  title?: string;
}

export default function Header({title}: HeaderInterface) {
  const insets = useSafeAreaInsets();

  return (
    <View style={{paddingTop: insets.top + 5}} className="bg-black/30 pb-4">
      <Icon
        name="chevron-left"
        size={28}
        color="#fff"
        className="absolute bottom-1 left-2 z-10"
        onPress={() => navigationRef.goBack()}
      />
      {title && (
        <DefaultText
          title={title}
          titleClassName="text-center font-sf-semibold text-lg"
        />
      )}
    </View>
  );
}
