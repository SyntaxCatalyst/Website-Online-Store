import React from 'react';
import {Text, TextProps} from 'react-native';

interface DefaultTextProps {
  subtitle?: string | number;
  subtitleClassName?: string;
  subtitlePress?: () => void;
  subtitleProps?: TextProps;
  title?: string | number;
  titleClassName?: string;
  titlePress?: () => void;
  titleProps?: TextProps;
}

export default function DefaultText({
  title,
  titleClassName,
  titlePress,
  titleProps,
  subtitle,
  subtitleClassName,
  subtitleProps,
  subtitlePress,
}: DefaultTextProps) {
  return (
    <Text
      className={`text-white font-sf-regular ${titleClassName}`}
      onPress={titlePress}
      {...titleProps}>
      {title}
      {subtitle && (
        <Text
          className={`text-white font-sf-regular ${subtitleClassName}`}
          onPress={subtitlePress}
          {...subtitleProps}>
          {' '}
          {subtitle}
        </Text>
      )}
    </Text>
  );
}
