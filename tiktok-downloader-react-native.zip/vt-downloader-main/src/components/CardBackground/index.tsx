import {
  Image,
  ImageSourcePropType,
  TouchableOpacity,
  useWindowDimensions,
} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAtomValue, useSetAtom} from 'jotai';
import {backgroundAtom, setBackgroundAtom} from '@src/store/UserStore';

export default function CardBackground({
  image,
  id,
}: {
  image: ImageSourcePropType;
  id: number;
}) {
  const background = useAtomValue(backgroundAtom);
  const setBackground = useSetAtom(setBackgroundAtom);
  const {width, height} = useWindowDimensions();

  return (
    <TouchableOpacity
      activeOpacity={0.7}
      className="self-center border border-white mb-3 justify-center"
      style={{width: width / 2, height: height / 2.5}}
      onPress={() => setBackground(id)}>
      <Image source={image} resizeMode="cover" className="w-full h-full" />
      {id === background && (
        <Icon
          name="check-circle"
          size={60}
          color="#fff"
          className="absolute self-center"
        />
      )}
    </TouchableOpacity>
  );
}
