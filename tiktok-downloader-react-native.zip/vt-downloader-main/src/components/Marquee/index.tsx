import React, {useEffect, useState} from 'react';
import {View} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';

interface MarqueeProps {
  text: string;
  speed?: number;
  className?: string;
}

const Marquee = ({
  text,
  speed = 50,
  className = 'text-white font-sf-regular',
}: MarqueeProps) => {
  const translateX = useSharedValue(0);
  const [containerWidth, setContainerWidth] = useState(0);
  const [textWidth, setTextWidth] = useState(0);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{translateX: translateX.value}],
  }));

  useEffect(() => {
    if (textWidth > 0 && containerWidth > 0) {
      const totalDistance = textWidth + containerWidth;
      const duration = (totalDistance / speed) * 1000;

      translateX.value = withRepeat(
        withTiming(-textWidth, {duration, easing: Easing.linear}),
        -1, // Infinite loop
        false,
      );
    }
  }, [textWidth, containerWidth, speed, translateX]);

  return (
    <View
      className="overflow-hidden flex-row items-center"
      onLayout={({nativeEvent}) => setContainerWidth(nativeEvent.layout.width)}>
      <Animated.Text
        onLayout={({nativeEvent}) => setTextWidth(nativeEvent.layout.width)}
        style={[animatedStyle]}
        className={`${className} whitespace-nowrap`}
        numberOfLines={1} // Ensures the text is a single line
      >
        {text}
      </Animated.Text>
    </View>
  );
};

export default Marquee;
