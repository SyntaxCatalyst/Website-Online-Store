import React from 'react';
import {Pressable} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import DefaultText from '../DefaultText';
import {translate} from '@src/locale';

export default function TabItem({
  isFocused,
  onPress,
  label,
}: {
  isFocused: boolean;
  onPress: () => void;
  label: string | any;
}) {
  const image = () => {
    if (label === 'Home') {
      return <Icon name="home" size={25} color={isFocused ? '#fff' : '#ccc'} />;
    } else if (label === 'History') {
      return (
        <Icon name="history" size={25} color={isFocused ? '#fff' : '#ccc'} />
      );
    } else if (label === 'Settings') {
      return <Icon name="cog" size={25} color={isFocused ? '#fff' : '#ccc'} />;
    }
  };

  const handlePress = () => {
    onPress();
  };

  return (
    <Pressable
      android_ripple={{
        color: '#ccc',
        borderless: true,
      }}
      onPress={handlePress}
      className="items-center">
      {image()}
      <DefaultText
        title={
          label === 'Home'
            ? translate('home')
            : label === 'History'
            ? translate('history')
            : label === 'Settings'
            ? translate('settings')
            : ''
        }
        titleClassName={`${
          isFocused ? 'font-sf-semibold text-white' : 'text-grey'
        }`}
      />
    </Pressable>
  );
}
