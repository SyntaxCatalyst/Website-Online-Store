import {Image, Text, TouchableOpacity, View} from 'react-native';
import React, {useState} from 'react';
import {VideoInterface} from '@src/interfaces/VideoInterface';
import dayjs from 'dayjs';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useSetAtom} from 'jotai';
import {removeDataListAtom} from '@src/store/UserStore';
import {navigationRef} from '@src/utils/navigation';
import ModalDownload from '../ModalDownload';
import ModalPercentage from '../ModalPercentage';
import useDownloadFile from '@src/hooks/useDownloadFiles';
import {onCopy} from '@src/utils/copy';
import {translate} from '@src/locale';

export default function CardVideo({
  item,
  isHistory = true,
}: {
  item: VideoInterface;
  isHistory?: boolean;
}) {
  const removeData = useSetAtom(removeDataListAtom);
  const [showModal, setShowModal] = useState(false);
  const {downloadProgress, downloadLoading, handleDownloadFiles} =
    useDownloadFile();

  const onDownload = () => {
    setShowModal(true);
  };

  const onPlay = () => {
    navigationRef.navigate('VideoDetails', {item});
  };

  const onDownloadVideo = () => {
    setShowModal(false);
    setTimeout(() => {
      handleDownloadFiles(
        item.type === 'video' ? [item.video.playAddr[0]] : item.images,
        item.type === 'video' ? 'video' : 'image',
      );
    }, 500);
  };

  const onDownloadAudio = () => {
    setShowModal(false);
    setTimeout(() => {
      handleDownloadFiles([item.music.playUrl[0]], 'audio');
    }, 500);
  };

  return (
    <>
      <ModalDownload
        show={showModal}
        hide={() => setShowModal(false)}
        item={item}
        onDownloadAudio={onDownloadAudio}
        onDownloadVideo={onDownloadVideo}
      />
      <ModalPercentage
        show={downloadLoading}
        percentage={(downloadProgress as number) ?? 100}
      />
      <View className="mb-3 bg-black/50 rounded-lg p-4 shadow-lg">
        <View className="flex-row items-center mb-3">
          <Image
            source={{uri: item.author.avatarMedium[0]}}
            className="w-8 h-8 rounded-full border border-gray-300"
            resizeMode="cover"
          />
          <Text className="text-white font-medium flex-1 ml-2">
            {item.author.nickname}
          </Text>
        </View>
        <Text className="text-white mb-3">{item.description}</Text>
        <View className="flex-row gap-2">
          <TouchableOpacity
            activeOpacity={0.7}
            className="bg-white/10 py-2 px-5 rounded flex-1 flex-row items-center justify-center gap-2"
            onPress={onPlay}>
            <Icon name="play" size={20} color="#fff" />
            <Text className="text-white font-medium">{translate('play')}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            activeOpacity={0.7}
            className="bg-white/10 py-2 px-5 rounded flex-1 flex-row items-center justify-center gap-2"
            onPress={onDownload}>
            <Icon name="download" size={20} color="#fff" />
            <Text className="text-white text-center font-medium">
              {translate('download')}
            </Text>
          </TouchableOpacity>
        </View>
        {isHistory && (
          <View className="flex-row items-center mt-3 gap-3">
            <Text className="text-gray-300 text-sm flex-1">
              {dayjs(item.date).format('DD/MM/YYYY')}
            </Text>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => onCopy(item.url)}>
              <Icon name="content-copy" size={18} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => removeData(item)}>
              <Icon name="delete" size={20} color="red" />
            </TouchableOpacity>
          </View>
        )}
      </View>
    </>
  );
}
