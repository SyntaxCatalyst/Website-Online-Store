import {View} from 'react-native';
import React from 'react';

export default function Choose({active}: {active: boolean}) {
  return (
    <View className="w-5 h-5 rounded-full border border-white justify-center items-center">
      {active && <View className="w-3 h-3 roundful bg-white rounded-full" />}
    </View>
  );
}
