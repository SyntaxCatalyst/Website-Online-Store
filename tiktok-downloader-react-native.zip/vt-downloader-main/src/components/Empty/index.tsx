import {Image, View, useWindowDimensions} from 'react-native';
import React from 'react';
import DefaultText from '../DefaultText';
import {translate} from '@src/locale';
import Gap from '../Gap';

export default function Empty() {
  const {height, width} = useWindowDimensions();

  return (
    <View style={{height: height / 1.6}} className="justify-center">
      <Image
        source={require('@src/assets/images/empty.png')}
        resizeMode="contain"
        style={{height: height / 4, width: width / 2}}
        className="self-center"
      />
      <Gap height={10} />
      <DefaultText
        title={translate('noData')}
        titleClassName="font-sf-semibold text-lg text-center"
      />
      <Gap height={10} />
      <DefaultText
        title={translate('noDataSub')}
        titleClassName="text-center"
      />
    </View>
  );
}
