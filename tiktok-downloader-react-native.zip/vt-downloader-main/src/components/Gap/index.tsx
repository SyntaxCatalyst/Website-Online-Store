import React from 'react';
import {View, ViewStyle} from 'react-native';

interface GapProps {
  className?: string;
  height?: number;
  style?: ViewStyle;
  width?: number;
}

export default function Gap({className, height, width, style}: GapProps) {
  return <View className={className} style={{width, height, ...style}} />;
}
