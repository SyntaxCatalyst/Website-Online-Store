import RNLanguageDetector from '@os-team/i18next-react-native-language-detector';
import i18next from 'i18next';
import {initReactI18next} from 'react-i18next';

import enMessages from './en.json';
import idMessages from './id.json';

export const allMessage = {
  en: enMessages,
  id: idMessages,
};

export const optionDetection = {
  lookupLocalStorage: 'en' as string,
};

const resources = {
  en: {translation: enMessages},
  id: {translation: idMessages},
};

i18next
  .use(initReactI18next)
  .use(RNLanguageDetector)
  .init({
    compatibilityJSON: 'v4',
    resources,
    fallbackLng: 'en',
    detection: optionDetection,
    interpolation: {
      escapeValue: false,
    },
  });

export default i18next;

export const translation = i18next;
export const {t: translate} = translation;
