import asyncHandler from 'express-async-handler'
import Tiktok from '@tobyg74/tiktok-api-dl'

export const downloadFromUrl = asyncHandler(async (req, res) => {
  const url = req.body.url

  if (!url) {
    res.status(400)
    throw new Error('Provide tiktok url!')
  }

  try {
    const response = await Tiktok.Downloader(url, { version: 'v3' })
    if (response.status === 'success') {
      res.json({ success: true, data: response.result })
    } else {
      res.status(500).json({ success: false, message: response.message })
    }
  } catch (error) {
    res.status(500)
    throw new Error('Try again later!')
  }
})

export const getTiktokFromUrl = asyncHandler(async (req, res) => {
  const url = req.query.url as string

  if (!url) {
    res.status(400)
    throw new Error('Provide tiktok url!')
  }

  try {
    const response = await Tiktok.Downloader(url, { version: 'v1' })
    if (response.status === 'success') {
      res.json({ success: true, data: response.result })
    } else {
      res.status(500).json({ success: false, message: response.message })
    }
  } catch (error) {
    res.status(500)
    throw new Error('Try again later!')
  }
})
