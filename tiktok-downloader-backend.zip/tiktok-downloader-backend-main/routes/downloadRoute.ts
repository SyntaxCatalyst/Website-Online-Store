import express from 'express'
import {
  downloadFromUrl,
  getTiktokFromUrl,
} from '../controllers/downloadController'

const router = express.Router()

router.post('/download', downloadFromUrl)
router.get('/download', getTiktokFromUrl)

export default router
