import express, { Application } from 'express'
import dotenv from 'dotenv'
import { notFound } from './middlewares/error'
import cors from 'cors'
import downloadRoute from './routes/downloadRoute'

dotenv.config()

const app: Application = express()

app.use(cors())
app.use(express.json())

app.get('/', (_, res) =>
  res.json({ success: true, message: 'Tiktok Downloader Backend' })
)

app.use('/tiktok', downloadRoute)

app.use(notFound)

const PORT = process.env.PORT
app.listen(PORT, (): void => console.log(`Server is running on ${PORT}`))
